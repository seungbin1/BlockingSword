﻿public static class AdmobIds
{

    //Admob Ids
    //public const string admobAppIdAndroid = "ca-app-pub-9117647008417542~2773743433";
    //public const string admobBannerIdAndroid = "ca-app-pub-3940256099942544/6300978111";
    //public const string admobInterstitialIdAndroid = "ca-app-pub-3940256099942544/1033173712";
    //public const string admobRewardIdAndroid = "ca-app-pub-3940256099942544/5224354917";

    //public const string admobAppIdIos = "ca-app-pub-9117647008417542~2773743433";
    //public const string admobBannerIdIos = "ca-app-pub-3940256099942544/6300978111";
    //public const string admobInterstitialIdIos = "ca-app-pub-3940256099942544/1033173712";
    //public const string admobRewardIdIos = "ca-app-pub-3940256099942544/5224354917";

    //Test Id
    public const string admobAppIdAndroid = "ca-app-pub-3942698952014764~5407681337";
    public const string admobBannerIdAndroid = "ca-app-pub-3942698952014764/4182229578";
    public const string admobInterstitialIdAndroid = "ca-app-pub-3942698952014764/7699443389";
    public const string admobRewardIdAndroid = "ca-app-pub-3942698952014764/6003218336";

    public const string admobAppIdIos = "ca-app-pub-9117647008417542~2773743433";
    public const string admobBannerIdIos = "ca-app-pub-3940256099942544/6300978111";
    public const string admobInterstitialIdIos = "ca-app-pub-3940256099942544/1033173712";
    public const string admobRewardIdIos = "ca-app-pub-3940256099942544/5224354917";
}
